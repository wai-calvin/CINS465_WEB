import React, { Component } from 'react';
import './stats.css';

class Stats extends Component {
  constructor() {
    super();
    this.state = {
      value: ''
    };
    this.handleKeyPress = this.handleKeyPress.bind(this);
  }

  componentDidMount() {
    document.addEventListener('keydown', this.handleKeyPress);
  }

  handleKeyPress(event) {
    if (event.keycode === 13) {

    }
  }

  render() {
    return (
      <div>
      </div>
    );
  }
}

export default Stats;
