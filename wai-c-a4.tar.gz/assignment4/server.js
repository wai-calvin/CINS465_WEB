const express = require('express');
const mysql = require('mysql');

const db = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : '@Ss4gogeta',
    database : 'tic_tac_toe_stats'
});

db.connect((err) => {
    if(err){
        throw err;
    }
    console.log('MySql Connected...');
});

const app = express();

app.get('/api/allstats', (req, res) => {
  let sql = "select * from stats";
  let query = db.query(sql, (err, result) => {
    if(err) throw err;
    console.log(result);
    res.send(result);
  })
})

app.get('/api/newPlayer/:name', (req, res) => {
  let sql = `INSERT INTO stats SET name = "${req.params.name}", xwins = 0, owins = 0, draws = 0`;
  let query = db.query(sql, (err, result) => {
    if(err) throw err
    console.log(result);
    res.send(result);
  })
})

app.get('/api/update/:name/:winner', (req, res) => {

  let sql;
  if(req.params.winner === "X"){
    sql = `update stats set xwins = xwins + 1 where name = "${req.params.name}"`;
  }
  else if(req.params.winner === "draw"){
    sql = `update stats set draws = draws + 1 where name = "${req.params.name}"`;
  }
  else{
    sql = `update stats set owins = owins + 1 where name = "${req.params.name}"`;
  }
  let query = db.query(sql, (err, result) => {
    if(err) throw err
    console.log(result);
    res.send(result);
  })
})

const port = 5000;

app.listen(port, () => `Server running on port ${port}`);
