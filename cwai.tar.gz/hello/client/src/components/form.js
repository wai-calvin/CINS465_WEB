import React, {Component} from 'react';

class Form extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: '',
      partySize: '',
      stats: []
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);

    fetch('/api/allstats')
    .then (response => {
      if (response.status !== 200) {
        console.log('allstats fetch problem - status code: ' + response.status);
        return;
      }

      response.json()
      .then(allstats => {
        console.log('allstats fetched: ');
        console.log(allstats);
        this.setState({stats: allstats});
      });
    })
    .catch(err => {
      console.log('allstats fetch error :-S', err);
    })
  }

  handleChange(event) {
    this.setState({
      [event.target.name]: event.target.value
    });
  }

  handleSubmit(event) {
    event.preventDefault();
    console.log(this.state);
    //this.props.onSubmit(this.state);
    const {onSubmit} = this.props;
    onSubmit(this.state);
    this.setState({
      name: '',
      partySize: ''
    });
  }

  render() {
    return (
      <form>
        <input
          name="name"
          placeholder='Name'
          value={this.state.name}
          onChange={this.handleChange}
        />

        <br />

        <input
          name="partySize"
          placeholder='Party Size'
          value={this.state.partySize}
          onChange={this.handleChange}
        />

        <button onClick={this.handleSubmit}>Submit</button>


      </form>
    );
  }

}

export default Form
