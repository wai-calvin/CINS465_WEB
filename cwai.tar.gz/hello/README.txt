README:

Users can insert their name and party size and be
added on the list.

If the max capacity of 25 is
reached, then users will have to wait for an available spot.

If the list is full, a timer set on 15 seconds will decrement.
At 0, it will remove the person thats been waiting the longest,
therefore creating more open space.

Users can edit their information as well as remove their
information if needed.
