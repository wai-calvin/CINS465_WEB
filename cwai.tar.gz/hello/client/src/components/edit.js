import React, {Component} from 'react';

class Edit extends Component {
    constructor(props) {
      super(props);
      this.state = {
        name: '',
        partySize: '',
        stats: [],
      };
      this.handleChange = this.handleChange.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this);

      fetch('/api/allstats')
      .then (response => {
        if (response.status !== 200) {
          console.log('allstats fetch problem - status code: ' + response.status);
          return;
        }

        response.json()
        .then(allstats => {
          console.log('allstats fetched: ');
          console.log(allstats);
          this.setState({stats: allstats});
        });
      })
      .catch(err => {
        console.log('allstats fetch error :-S', err);
      })
    }

    handleChange(event) {
      this.setState({
        [event.target.name]: event.target.value
      });
    }

    handleSubmit(event) {
      event.preventDefault();
      this.props.editUpdate(this.state);
      this.setState({
        name: '',
        partySize: ''
      });

      for (var i = 0; i < this.state.stats.length; i++) {
        if (this.state.name === this.state.stats[i].name) {

          fetch('/api/update/' + this.state.name + '/' + this.state.partySize)
          .then (response => {
            if (response.status !== 200) {
              console.log('update fetch problem - status code: ' + response.status);
              return;
            }

            response.json()
            .then(updates => {
              console.log('updates fetched: ');
              console.log(updates);
              this.setState({stats: updates});
            });
          })
        }
      }
    }

    render() {
      return (
        <form>
          <input
            name="name"
            placeholder='Name to search'
            value={this.state.name}
            onChange={this.handleChange}
          />

          <br />

          <input
            name="partySize"
            placeholder='New Party Size'
            value={this.state.partySize}
            onChange={this.handleChange}
          />

          <button onClick={this.handleSubmit}>Submit</button>
        </form>
      );
    }
}

export default Edit
