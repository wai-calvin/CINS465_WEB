import React, { Component } from 'react';
//import logo from './logo.svg';
import './App.css';
//import Request from './components/request';
import Form from './components/form';
import Edit from './components/edit';
import Remove from './components/remove';
import Timer from './components/timer';

const maxCapacity = 25;

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      visibility: false,
      remove: false,
      name: '',
      partySize: '',
      currCapacity: '',
      stats: []
    };
    this.onSubmit = this.onSubmit.bind(this);
    this.updateList = this.updateList.bind(this);
    this.toggleVisibility = this.toggleVisibility.bind(this);
    this.toggleRemove = this.toggleRemove.bind(this);
  }

  toggleVisibility() {
    if(this.state.visibility === true) {
      this.setState({
        visibility: false
      });
    }
    else {
      this.setState({
        visibility: true
      });
    }
  }

  toggleRemove() {
    if (this.state.remove === true) {
      this.setState({
        remove: false
      });
    }
    else {
      this.setState({
        remove: true
      });
    }
  }

  updateList(x) {
    this.setState({
      stats: x.stats
    });
  }

  onSubmit(fields) {

    this.setState({
      name: fields.name,
      partySize: fields.partySize,
      stats: fields.stats
    });

    var exists = 0;
    var currentCount = 0;

    for (var i = 0; i < fields.stats.length; i++) {
      currentCount = currentCount + fields.stats[i].partySize;
      if (fields.name === fields.stats[i].name) {
        alert('User already in line');
        exists = 1;
      }
    }

    if (currentCount >= maxCapacity) {
      alert('Sorry! Queue is currently full.');
    }

    else if (exists === 0) {
      fetch('/api/insert/' + fields.name + '/' + fields.partySize)
      .then (response => {
        if (response.status !== 200) {
          console.log('insert fetch problem - status code: ' + response.status);
          return;
        }
        response.json()
        .then(allstats => {
          this.setState({stats: allstats});
        });
      })
      console.log(currentCount);
    }

    for (var j = 0; j < fields.stats.length; j++) {
      currentCount = currentCount + fields.stats[j].partySize;
      if (fields.name === fields.stats[j].name) {
        alert('User already in line');
        exists = 1;
      }
    }

    if (exists === 0) {
      fetch('/api/insert/' + fields.name + '/' + fields.partySize)
      .then (response => {
        if (response.status !== 200) {
          console.log('insert fetch problem - status code: ' + response.status);
          return;
        }
        response.json()
        .then(allstats => {
          this.setState({stats: allstats});
        });
      })
    }
  }

  render() {
    if (this.state.visibility) {
      return (
        <div>
          <div>
            <button onClick={this.toggleVisibility}>Edit</button>
            {!this.state.hidden &&
            <Edit
              name={this.state.name}
              partySize={this.state.partySize}
              onSubmit={this.updateList}
            />}
          </div>
        </div>
      );
    }
    else if (this.state.remove) {
      return (
        <div>
          <div>
            <button onClick={this.toggleRemove}>Edit</button>
            {!this.state.hidden &&
            <Remove
              name={this.state.name}
              partySize={this.state.partySize}
              onSubmit={this.updateList}
            />}
          </div>
        </div>
      );
    }
    else {
      return (
        <div>
          <Form onSubmit={this.onSubmit}/>
          <button onClick={this.toggleVisibility}>Edit</button>
          <button onClick={this.toggleRemove}>Remove</button>
          <Timer />
        </div>
      );
    }
  }
}

export default App;
