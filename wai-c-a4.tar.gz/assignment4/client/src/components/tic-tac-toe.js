import React from 'react';
import './tic-tac-toe.css';

let endGame = 0;
let value = '';

function Square(props) {
  return (
    <button className="square" onClick={props.onClick}>
      {props.value}
    </button>
  );
}

class Board extends React.Component {
  renderSquare(i) {
    return (
      <Square
        value={this.props.squares[i]}
        onClick={() => this.props.onClick(i)}
      />
    );
  }

  render() {
    return (
      <div>
        <div className="board-row">
          {this.renderSquare(0)}
          {this.renderSquare(1)}
          {this.renderSquare(2)}
        </div>
        <div className="board-row">
          {this.renderSquare(3)}
          {this.renderSquare(4)}
          {this.renderSquare(5)}
        </div>
        <div className="board-row">
          {this.renderSquare(6)}
          {this.renderSquare(7)}
          {this.renderSquare(8)}
        </div>
      </div>
    );
  }
}

class Game extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      stats: [],
      value: '',
      history: [
        {
          squares: Array(9).fill(null)
        }
      ],
      stepNumber: 0,
      xIsNext: true,
    };

    // Initial fetch for stats table.
    fetch('/api/allstats')
    .then (response =>{
      if (response.status !== 200) {
        console.log('allstats fetch problem - status code: ' + response.status);
        return;
      }

      response.json()
      .then(allstats => {
        console.log('allstats fetched: ');
        console.log(allstats);
        this.setState({stats: allstats});
      });
    })
    .catch(err => {
      console.log('allstats fetch error error :-S', err);
    })
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  // Set state of value to the value of user input (i.e. their username)
  handleChange(event) {
    this.setState({value: event.target.value});
  }

  // handleSubmit() first clears the input box. Then, it checks
  // if the name that was inputed exists. If so, that user can play.
  // If user does not exist, then a new user is created and stats
  // for that player will be kept track of starting at 0.
  handleSubmit(event) {
    let match = 0;
    event.preventDefault();
    value = this.state.value;
    this.setState({value: ''});

    for (let i = 0; i < this.state.stats.length; i++) {
      if (this.state.stats[i].name === value) {
        match = 1;
      }
    }

    if (match === 1) {
      return;
    }

    else {
      fetch('/api/newPlayer/' + value)

      fetch('/api/allstats')
      .then (response =>{
        if (response.status !== 200) {
          console.log('allstats fetch problem - status code: ' + response.status);
          return;
        }

        response.json()
        .then(allstats => {
          console.log('allstats fetched: ');
          console.log(allstats);
          this.setState({stats: allstats});
        });
      })
      .catch(err => {
        console.log('allstats fetch error error :-S', err);
      })
    }
  }

  handleClick(i) {
    const history = this.state.history.slice(0, this.state.stepNumber + 1);
    const current = history[history.length - 1];
    const squares = current.squares.slice();
    if (calculateWinner(squares) || squares[i]) {
      return;
    }
    squares[i] = this.state.xIsNext ? "X" : "O";
    this.setState({
      history: history.concat([
        {
          squares: squares
        }
      ]),
      stepNumber: history.length,
      xIsNext: !this.state.xIsNext
    });
  }

  jumpTo(step) {
    this.setState({
      stepNumber: step,
      xIsNext: (step % 2) === 0
    });
  }

  // Updates a players xwins when a player wins a game, then re-renders
  // the stats table.
  updateWinner(winner) {
    fetch('/api/update/' + value + '/' + winner)

    fetch('/api/allstats')
    .then (response =>{
      if (response.status !== 200) {
        console.log('allstats fetch problem - status code: ' + response.status);
        return;
      }

      response.json()
      .then(allstats => {
        console.log('allstats fetched: ');
        console.log(allstats);
        this.setState({stats: allstats});
      });
    })
    .catch(err => {
      console.log('allstats fetch error error :-S', err);
    })
  }

  // Draws are now accounted for and displayed upon reaching
  // end of game. Winning symbol is passed to updateWinner() for
  // the stats table to be updated.
  render() {
    const history = this.state.history;
    const current = history[this.state.stepNumber];
    let winner = calculateWinner(current.squares);

    const moves = history.map((step, move) => {
      const desc = move ?
        'Go to move #' + move :
        'Go to game start';
      return (
        <li key={move}>
          <button onClick={() => this.jumpTo(move)}>{desc}</button>
        </li>
      );
    });

    let status;
    if (winner && winner !== "draw") {
      status = "Winner: " + winner;
    }
    else if(winner === "draw"){
      status = "Draw";
    }else {
      status = "Next player: " + (this.state.xIsNext ? "X" : "O");
    }

    if (winner && !endGame) {
      endGame = 1;
      this.updateWinner(winner);
    }

    return (
      <div className="game row">

        <div className="game-board game-info column">
          <div><b>{status}</b></div>
          <Board
            squares={current.squares}
            onClick={i => this.handleClick(i)}
          />
          <ol>{moves}</ol>
        </div>

        <div className="column">
          <form onSubmit={this.handleSubmit}>
            <label>
              <b>Type your name and hit ENTER:</b>
              <br />
              <input type="text"
              value={this.state.value}
              onChange={this.handleChange}
              placeholder="Type your name here" />
            </label>
          </form>
          <p id="userName"></p>
        </div>

        <div>
          <h2>Statistics</h2>
          <table>
            <tbody>
              <tr>
                <th>Name</th>
                <th>X Wins</th>
                <th>O Wins</th>
                <th>Draws</th>
              </tr>

              {this.state.stats.map(statistics =>
                <tr>
                  <td id="nameColor">{statistics.name}</td>
                  <td>{statistics.xwins}</td>
                  <td>{statistics.owins}</td>
                  <td>{statistics.draws}</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

// ========================================
// Checks for end of game. If end of game is not reached,
// it will always check to see if every square is filled up.
// If so, then a draw has been reached.
function calculateWinner(squares) {
  const lines = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
  ];
  for (let i = 0; i < lines.length; i++) {
    const [a, b, c] = lines[i];
    if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
      return squares[a];
    }
    else if (squares[0] && squares[1] && squares[2] &&
      squares[3] && squares[4] && squares[5] &&
    squares[6] && squares[7] && squares[8]){
      return "draw";
    }
  }
  return null;
}

export default Game;
