import React, {Component} from 'react';

class List extends Component {
  constructor(props) {
    super(props);
    this.State = {
      stats: {}
    }

    fetch('/api/allstats')
    .then (response => {
      if (response.status !== 200) {
        console.log('allstats fetch problem - status code: ' + response.status);
        return;
      }

      response.json()
      .then(allstats => {
        console.log('allstats fetched: ');
        console.log(allstats);
        this.setState({stats: allstats});
      });
    })
    .catch(err => {
      console.log('allstats fetch error :-S', err);
    })
  }

  render() {
    return (
      <div>
        <h1>{this.state.stats.name}</h1>
      </div>
    );
  }
}

export default List
