import React, {Component} from 'react';

class Timer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      time: 15,
      nameToDelete: '',
      stats: []
    };

    fetch('/api/allstats')
    .then (response => {
      if (response.status !== 200) {
        console.log('allstats fetch problem - status code: ' + response.status);
        return;
      }

      response.json()
      .then(allstats => {
        console.log('allstats fetched: ');
        console.log(allstats);;
        this.setState({stats: allstats});
      });
    })
  }

  render() {
    const {time} = this.state;
    return (
      <div>
        <p>Current time: {time}</p>
      </div>
    );
  }

  componentDidMount() {
    this.myInterval = setInterval( () => this.tick(), 1000);
  }

  componentWillUnmount() {
    clearInterval(this.myInterval)
  }

  tick() {
    if(this.state.time > 0) {
      this.setState(prevState => ({
        time: prevState.time - 1
      }))
    }

    else {
      console.log(this.state.stats.length);
      if(this.state.stats.length === 0) {
        this.setState({ time: 16 })
        this.tick();
      }

      else {
        fetch('/api/deleteElement/')

        fetch('/api/allstats')
        .then (response => {
          if (response.status !== 200) {
            console.log('allstats fetch problem - status code: ' + response.status);
            return;
          }
          response.json()
          .then(allstats => {
            console.log('allstats fetched: ');
            console.log(allstats);;
            this.setState({stats: allstats});
          });
        })
        this.setState({ time: 16 });
        this.tick();
      }
    }
  }
}

export default Timer
