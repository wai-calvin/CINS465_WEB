import React, { Component } from 'react';

class Remove extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: '',
      partySize: '',
      stats: [],
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);

    fetch('/api/allstats')
    .then (response => {
      if (response.status !== 200) {
        console.log('allstats fetch problem - status code: ' + response.status);
        return;
      }

      response.json()
      .then(allstats => {
        console.log('allstats fetched: ');
        console.log(allstats);
        this.setState({stats: allstats});
      });
    })
  }

  handleChange(event) {
    this.setState({
      [event.target.name]: event.target.value
    });
  }

  handleSubmit(event) {
    event.preventDefault();
    this.props.onSubmit(this.state);
    this.setState({
      name: '',
      partySize: '',
    })

    console.log(this.state.name);

    fetch('/api/remove/' + this.state.name)
    .then (response => {
      if (response.status !== 200) {
        console.log('allstats fetch problem - status code: ' + response.status);
        return;
      }

      response.json()
      .then(allstats => {
        console.log('allstats fetched: ');
        console.log(allstats);
        this.setState({stats: allstats});
      });
    })
  }


  render() {
    return (
      <form>
        <input
          name="name"
          placeholder='Name to remove'
          value={this.state.name}
          onChange={this.handleChange}
        />
        <button onClick={this.handleSubmit}>Submit</button>


      </form>
    );
  }
}

export default Remove
